Change Log
==========

Version 1.0.0 *(2016-10-09)*
----------------------------

Initial release.
